<?php
require_once trailingslashit( PGSCORE_PATH ) . 'includes/icons/font-awesome-array.php';
