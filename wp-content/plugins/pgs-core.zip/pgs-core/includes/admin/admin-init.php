<?php
require_once trailingslashit( PGSCORE_PATH ) . 'includes/admin/class.system-status.php'; // class Pgs_Core_System_Status
require_once trailingslashit( PGSCORE_PATH ) . 'includes/admin/panel/panel.php';         // CiyaShop Panel
require_once trailingslashit( PGSCORE_PATH ) . 'includes/admin/side-guide.php'; // CiyaShop Size Guide
