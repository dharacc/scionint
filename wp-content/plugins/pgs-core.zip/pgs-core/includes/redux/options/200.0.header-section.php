<?php
return array(
	'title'            => esc_html__( 'Header', 'pgs-core' ),
	'id'               => 'Header_section',
	'customizer_width' => '400px',
	'icon'             => 'el el-arrow-up',
);
