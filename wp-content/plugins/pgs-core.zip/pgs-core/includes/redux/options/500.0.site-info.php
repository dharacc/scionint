<?php
return array(
	'title' => esc_html__( 'Site Info', 'pgs-core' ),
	'id'    => 'site_info_section',
	'icon'  => 'el el-cogs',
);
