<?php
return array(
	'title'            => esc_html__( 'Typography', 'pgs-core' ),
	'id'               => 'Typography_section_title',
	'customizer_width' => '400px',
	'icon'             => 'el el-font',
);
