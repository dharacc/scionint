<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

do_action( "pgssl_component_help_sidebar_start" );

do_action( "pgssl_component_help_sidebar_end" );
