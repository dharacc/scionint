<?php
return array(
	'title' => esc_html__( 'Typography', 'pgs-core' ),
	'id'    => 'typography_font_section',
	'icon'  => 'el el-font',
);
